<?php

return [
    'failed' => 'Nieprawidłowe dane logowania.',
    'password' => 'Podane hasło jest nieprawidłowe.',
    'throttle' => 'Zbyt wiele prób logowania. Spróbuj ponownie za :seconds sekund.',
];

